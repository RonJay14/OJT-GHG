<!-- templates/emu_sidenav_fuel.html -->
<ul class="nav flex-column">
    <li class="nav-item">
        <a class="nav-link" href="{{ url_for('fuel_emissions') }}">Fuel Emissions</a>
    </li>
</ul>
